Connect Four - Starter Kit 

Author: Eikester

Make your own Connect Four Games with this Starter Kit.

Features:
-variable number of Columns and Rows, default 6x7
-variable number of Pieces needed to win e.g. connect 5 Game
-Allow/disallow Diagonally Lines
-simple AI

Usage:
Simply open the game scene, adjust GameController to your liking and Play

Credits:
Kenney.nl for Sprites, Soundeffect and Font

Contact:
eikester@hotmail.de


